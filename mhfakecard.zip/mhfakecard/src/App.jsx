import React from 'react'
import PdfEditor from './components/PdfEditor'

export default function App(){
  return (
    <div className="app-bg">
      <header className="header">
        <div className="logo">MH Fake Card Editor</div>
      </header>
      <main className="container">
        <PdfEditor />
      </main>
    </div>
  )
}
