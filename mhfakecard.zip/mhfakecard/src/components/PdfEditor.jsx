import React, { useRef, useState, useEffect } from 'react'
import * as pdfjsLib from 'pdfjs-dist/legacy/build/pdf.js'
import { PDFDocument, rgb } from 'pdf-lib'
import { saveAs } from 'file-saver'

// NOTE: pdfjs workerPath will be resolved from node_modules when built by Vite.
// For dev, we set the workerSrc dynamically.
pdfjsLib.GlobalWorkerOptions.workerSrc = '/node_modules/pdfjs-dist/build/pdf.worker.js';

export default function PdfEditor(){
  const [fileBuffer, setFileBuffer] = useState(null)
  const [pdfDoc, setPdfDoc] = useState(null)
  const [pages, setPages] = useState([]) // {canvasRef, viewport, textItems}

  const fileInputRef = useRef()

  const handleFile = (e) => {
    const f = e.target.files?.[0]
    if(!f) return
    const reader = new FileReader()
    reader.onload = async () => {
      const arr = new Uint8Array(reader.result)
      setFileBuffer(arr)
      await loadPdf(arr)
    }
    reader.readAsArrayBuffer(f)
  }

  async function loadPdf(uint8arr){
    const loadingTask = pdfjsLib.getDocument({data:uint8arr})
    const pdf = await loadingTask.promise
    setPdfDoc(pdf)
    const tempPages = []
    for(let i=1;i<=pdf.numPages;i++){
      const page = await pdf.getPage(i)
      const viewport = page.getViewport({scale:1.5})
      // Render to canvas
      const canvas = document.createElement('canvas')
      canvas.width = viewport.width
      canvas.height = viewport.height
      const ctx = canvas.getContext('2d')
      await page.render({canvasContext:ctx, viewport}).promise
      // Extract text items
      const textContent = await page.getTextContent()
      const textItems = textContent.items.map(item=>{
        return {
          str: item.str,
          transform: item.transform,
          width: item.width,
          height: item.height,
          fontName: item.fontName
        }
      })
      tempPages.push({canvas, viewport, textItems, pageIndex: i})
    }
    setPages(tempPages)
  }

  function renderPages(){
    return pages.map((p, idx)=>{
      return (
        <div key={idx} className="page-wrapper" style={{width: p.canvas.width}}>
          <div style={{position:'relative', width:p.canvas.width}}>
            <canvas ref={el => {
              if(el && !el._filled){
                el._filled = true
                el.width = p.canvas.width
                el.height = p.canvas.height
                const ctx = el.getContext('2d')
                ctx.drawImage(p.canvas,0,0)
              }
            }} />
            <div className="text-layer" style={{width:p.canvas.width, height:p.canvas.height}}>
              {p.textItems.map((t, ti)=> {
                // Compute position from transform matrix (approx)
                const scale = p.viewport.scale
                // transform format: [a, b, c, d, e, f] where e,f are x,y
                const e = t.transform[4]
                const f = t.transform[5]
                const style = {
                  left: e*scale,
                  top: (p.viewport.height - f*scale) -  (t.height*scale),
                  fontSize: 12*scale,
                  maxWidth: Math.max(20, t.width*scale)
                }
                return (
                  <div
                    key={ti}
                    className="text-item"
                    style={style}
                    contentEditable
                    suppressContentEditableWarning
                    onDoubleClick={(ev)=> {
                      // allow edit (already contentEditable). focus
                      ev.currentTarget.focus()
                    }}
                    onBlur={(ev)=>{
                      const newText = ev.currentTarget.innerText
                      // update pages state with new text
                      setPages(prev => {
                        const copy = prev.map(pp=> ({...pp, textItems: pp.textItems.map(x=>({...x}))}))
                        copy[idx].textItems[ti].str = newText
                        return copy
                      })
                    }}
                  >
                    {t.str}
                  </div>
                )
              })}
            </div>
          </div>
        </div>
      )
    })
  }

  async function handleSave(){
    if(!fileBuffer) return alert('Upload a PDF first.')
    const pdfLibDoc = await PDFDocument.load(fileBuffer)
    const pagesLib = pdfLibDoc.getPages()
    // For each page, we'll draw edited text items over the page.
    for(let i=0;i<pages.length;i++){
      const page = pages[i]
      const libPage = pagesLib[i]
      // Draw white rectangle (transparent) not necessary; we'll draw text
      const { width, height } = libPage.getSize()
      const textItems = page.textItems
      for(const t of textItems){
        // transform e,f approximate from pdf.js values (we stored transformed positions)
        const e = t.transform ? t.transform[4] : 0
        const f = t.transform ? t.transform[5] : 0
        const x = e
        const y = f
        // pdf-lib coordinate system: origin bottom-left; pdf.js gives transform with y from bottom, approximate
        libPage.drawText(t.str || '', {
          x: x,
          y: y,
          size: 10,
          color: rgb(0,0,0),
        })
      }
    }
    const pdfBytes = await pdfLibDoc.save()
    const blob = new Blob([pdfBytes], {type:'application/pdf'})
    saveAs(blob, 'mhfakecard-edited.pdf')
  }

  return (
    <div>
      <div className="controls">
        <input ref={fileInputRef} type="file" accept="application/pdf" onChange={handleFile} />
        <button className="btn" onClick={handleSave}>Download Edited PDF</button>
        <button className="btn secondary" onClick={()=>{ setPages([]); setFileBuffer(null); fileInputRef.current.value = null}}>Clear</button>
      </div>
      <div className="pdf-area">
        {pages.length ? renderPages() : <div style={{color:'var(--muted'}}>Upload a PDF to begin — pages will render below.</div>}
      </div>
    </div>
  )
}
