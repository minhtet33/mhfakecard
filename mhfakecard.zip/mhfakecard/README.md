# mhfakecard — AI PDF Full Editor (Online-ready)

This is a minimal online-ready React app (Vite) that implements:
- Upload PDF
- Render pages using pdf.js
- Overlay editable text blocks (double-click to edit / delete)
- Regenerate and download edited PDF using pdf-lib

Quick start (online, Replit/Vercel):
1. Upload the ZIP contents to Replit or another online runner.
2. Run `npm install`
3. Run `npm run dev`

Notes:
- This project uses a simple CSS file for styling (ivory background).
- For production-grade Tailwind integration, add Tailwind build steps.
